attributes:
    (alternate 1 0)
    (bar 1 0)
    (fri/sat 1 0)
    (hungry 1 0)
    (patrons 0 0.5 1) ;; none some full
    (price 0 0.5 1)
    (raining 1 0)
    (reservation 1 0)
    (type 1 0.67 0.33 0)  ;; french italian thai burger
    (waitestimate 0 0.17 0.5 1))  ;; >= 0 10 30 60 minutes

goals:
    ((willwait 1 0))


total_num: 100
train_size： 75
test_size:     25